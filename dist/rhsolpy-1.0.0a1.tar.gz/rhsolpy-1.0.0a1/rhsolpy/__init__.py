from . import rankine_hugoniot

__version__ = '1.0.0-alpha.1'